package Percistencia;

import Modelo.CCorrente;
import Modelo.CEspecial;
import Modelo.Cliente;
import Modelo.ListarContas;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JBDCConta {
    Connection conexao;

    public JBDCConta(Connection conexao) {
        this.conexao = conexao;
    }
    public ArrayList<Cliente> listarComboClientes() {
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        String sql = "select * from cliente";

        try {
            Statement declaracao;
            declaracao = conexao.createStatement();
            ResultSet resposta = declaracao.executeQuery(sql);
            while (resposta.next()) {
                int id = resposta.getInt("id");
                String nome = resposta.getString("nome");
                Cliente c = new Cliente(id, nome);
                clientes.add(c);
            }
        } catch (SQLException e) { e.printStackTrace();}
        
        return clientes;
    }
    
    public void apagarCliente() {
        String sql = "delete from cliente";
        PreparedStatement ps;
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void inserirCCorrente(CCorrente cc) {
        String sql = "insert into ccorrente (numero,saldo,fk_cliente) values (?,?,?)";
        PreparedStatement ps;
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.setInt(1, cc.getNumero());
            ps.setDouble(2, cc.getSaldo());
            ps.setInt(3, cc.getFkCliente().getId());
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    public void apagarCorrente() {
        String sql = "delete from ccorrente";
        PreparedStatement ps;
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    public void inserirCEspecial(CEspecial ce) {
        String sql = "insert into cespecial (numero,saldo,limite,fk_cliente) values (?,?,?,?)";
        PreparedStatement ps;
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.setInt(1, ce.getNumero());
            ps.setDouble(2, ce.getSaldo());
            ps.setInt(3, ce.getLimite());
            ps.setInt(4, ce.getFkCliente().getId());
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
     public void apagarEspecial() {
        String sql = "delete from cespecial";
        PreparedStatement ps;
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    public ArrayList<ListarContas> listarContas() {
        ArrayList<ListarContas> contas = new ArrayList<ListarContas>();
        String sql = "select ccorrente.*, cliente.nome from ccorrente, cliente where ccorrente.numero = cliente.id";
        String sql1 = "select cespecial.*, cliente.nome from cespecial, cliente where cespecial.numero = cliente.id";
        
        try {
            Statement declaracao;
            declaracao = conexao.createStatement();
            ResultSet resposta = declaracao.executeQuery(sql);
            while(resposta.next()) {
                int num = resposta.getInt("numero");
                double sal = resposta.getDouble("saldo");
                String n = resposta.getString("nome");
                ListarContas lcc = new ListarContas(num,sal,n, "Corrente");
                contas.add(lcc);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        
        try {
            Statement declaracao1;
            declaracao1 = conexao.createStatement();
            ResultSet resposta1 = declaracao1.executeQuery(sql1);
            while(resposta1.next()) {
                int num = resposta1.getInt("numero");
                double sal = resposta1.getDouble("saldo");
                int lim = resposta1.getInt("limite");
                String n = resposta1.getString("nome");
                ListarContas lce = new ListarContas(num, lim, sal, n, "Especial");
                contas.add(lce);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        
        return contas;
    }
    
    public ArrayList<CCorrente> listarComboCCorrente(){
        ArrayList<CCorrente> ccorrente = new ArrayList<CCorrente>();
        String sql = "select * from ccorrente";
        try{
            Statement declaracao;
            declaracao = conexao.createStatement();
            ResultSet resposta = declaracao.executeQuery(sql);
            while(resposta.next()){
                int num = resposta.getInt("numero");
                double saldo = resposta.getDouble("saldo");
                CCorrente cc = new CCorrente(num, saldo);
                ccorrente.add(cc);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        
        return ccorrente;
    }
    
    public ArrayList<CEspecial> listarComboCEspecial(){
        ArrayList<CEspecial> cespecial = new ArrayList<CEspecial>();
        String sql = "select * from cespecial";
        try{
            Statement declaracao;
            declaracao = conexao.createStatement();
            ResultSet resposta = declaracao.executeQuery(sql);
            while(resposta.next()){
                int num = resposta.getInt("numero");
                double saldo = resposta.getDouble("saldo");
                int lim = resposta.getInt("limite");
                CEspecial ce = new CEspecial(num, saldo, lim);
                cespecial.add(ce);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        
        return cespecial;
    }
    
    public void alterarSaldoCorrente(CCorrente cc){
        String sql = "update ccorrente set  saldo=? where numero =?";
        PreparedStatement ps;
        try{
            ps = this.conexao.prepareStatement(sql);
            ps.setDouble(1, cc.getSaldo());
            ps.setInt(2, cc.getNumero());
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    public void alterarSaldoEspecial(CEspecial ce){
        String sql = "update cespecial set  saldo=? where numero =?";
        PreparedStatement ps;
        try{
            ps = this.conexao.prepareStatement(sql);
            ps.setDouble(1, ce.getSaldo());
            ps.setInt(2, ce.getNumero());
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
}
