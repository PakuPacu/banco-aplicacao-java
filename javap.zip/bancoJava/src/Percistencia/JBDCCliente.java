package Percistencia;

import Modelo.Cliente;
import Modelo.CCorrente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JBDCCliente {

    Connection conexao;

    public JBDCCliente(Connection conexao) {
        this.conexao = conexao;
    }

    public void inserirCliente(Cliente c) {
        String sql = "insert into cliente(nome, CPF) values(?,?)";
        PreparedStatement ps;

        try {
            ps = this.conexao.prepareStatement(sql);
            ps.setString(1, c.getNome());
            ps.setString(2, c.getCpf());
            ps.execute();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public ArrayList<Cliente> listarClientes() {
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        String sql = "select * from cliente";

        try {
            Statement declaracao = conexao.createStatement();
            ResultSet resposta = declaracao.executeQuery(sql);

            while (resposta.next()) {
                int id = resposta.getInt("id");
                String nome = resposta.getString("nome");
                String cpf = resposta.getString("CPF");
                Cliente c = new Cliente(id, nome, cpf);
                clientes.add(c);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return clientes;
    }
}
