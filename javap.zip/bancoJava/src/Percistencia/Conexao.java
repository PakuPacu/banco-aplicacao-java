package Percistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private Connection conexao;
    public Connection abrirConexao(){
        String url = "jdbc:mysql://localhost:3306/clienteBancodDados?useTimezone=true&serverTimezone=UTC";
        String user = "root";
        String password = "";
        
        try{
            conexao = DriverManager.getConnection(url, user, password);
        } catch(SQLException e){ e.printStackTrace(); }
        return conexao;
    }
    
    public void fecharConexao(){
        try{
            conexao.close();
        } catch(SQLException e){ e.printStackTrace(); }
    }
}
