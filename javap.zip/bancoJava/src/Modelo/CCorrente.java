package Modelo;

public class CCorrente {
    private int numero;
    private Cliente fkCliente;
    private double saldo;

    public CCorrente(int numero, double saldo, Cliente fkCliente) {
        this.numero = numero;
        this.fkCliente = fkCliente;
        this.saldo = saldo;
    }

    public CCorrente(int numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }
      
     public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setFkCliente(Cliente fkCliente) {
        this.fkCliente = fkCliente;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public int getNumero() {
        return numero;
    }

    public Cliente getFkCliente() {
        return fkCliente;
    }

    public double getSaldo() {
            return saldo;
    }
    
    public void debitar(double valor) {
        if(valor <= this.saldo)
            this.saldo -= valor;
        else
            System.out.println("Saldo Insuficiente");
    }
    
    public void creditar(double valor) {
        this.saldo += valor;
    }

    @Override
    public String toString() {
        return "(" + numero + ")" + " " + saldo;
    }
}
