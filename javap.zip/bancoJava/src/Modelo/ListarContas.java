package Modelo;

public class ListarContas {
    private int numero, limite;
    private double saldo;
    private String cliente;
    private String conta;
    public ListarContas(int numero, double saldo, String cliente, String conta) {
        this.numero = numero;
        this.saldo = saldo;
        this.cliente = cliente;
        this.conta = conta;
    }

    public ListarContas(int numero, int limite, double saldo, String cliente, String conta) {
        this.numero = numero;
        this.limite = limite;
        this.saldo = saldo;
        this.cliente = cliente;
        this.conta = conta;
    }

    public int getNumero() {
        return numero;
    }

    public int getLimite() {
        return limite;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getCliente() {
        return cliente;
    }
    
    public String getConta() {
        return conta;
    }
    
}
