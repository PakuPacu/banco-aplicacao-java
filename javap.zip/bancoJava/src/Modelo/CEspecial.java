package Modelo;

public class CEspecial {
    private int numero, limite;
    private Cliente fkCliente;
    private double saldo;
    
    public CEspecial(int numero, int limite, Cliente fkCliente, double saldo) {
        this.numero = numero;
        this.limite = limite;
        this.fkCliente = fkCliente;
        this.saldo = saldo;
    }

    public CEspecial(int numero, double saldo, int limite) {
        this.numero = numero;
        this.saldo = saldo;
        this.limite = limite;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setLimite(int limite) {
        this.limite = limite;
    }

    public void setFkCliente(Cliente fkCliente) {
        this.fkCliente = fkCliente;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public int getNumero() {
        return numero;
    }

    public int getLimite() {
        return limite;
    }

    public Cliente getFkCliente() {
        return fkCliente;
    }

    public double getSaldo() {
        return saldo;
    }
    
    public void debitar(double valor) {
        if(valor <= (this.saldo + this.limite))
            this.saldo -= valor;
        else
            System.out.println("Saldo Insuficiente");
    }
    
    public void creditar(double valor) {
        this.saldo += valor;
    }
    
    @Override
    public String toString() {
        return "(" + numero + ")" + " " + saldo;
    }
}
