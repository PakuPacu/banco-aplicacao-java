package Modelo;

public class Cliente {
    private int Id;
    private String Nome, Cpf;

    public Cliente(int Id, String Nome, String Cpf) {
        this.Id = Id;
        this.Nome = Nome;
        this.Cpf = Cpf;
    }
    
    public Cliente(int Id, String Nome) {
        this.Id = Id;
        this.Nome = Nome;
    }
    
    public int getId(){
        return Id;
    }
    
    public String getNome() {
        return Nome;
    }
    
    public String getCpf() {
        return Cpf;
    }
    
    @Override
    public String toString() {
        return Nome;
    }
    
}
